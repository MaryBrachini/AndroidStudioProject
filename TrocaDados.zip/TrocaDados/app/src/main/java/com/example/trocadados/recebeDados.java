package com.example.trocadados;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class recebeDados extends AppCompatActivity {
    private TextView textNome, textIdade;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recebe_dados);

        textNome=findViewById(R.id.textNome);
        textIdade=findViewById(R.id.textIdade);

        String nome;
        int idade;

        Bundle dados=getIntent().getExtras();

        nome=dados.getString("nome");
        idade=dados.getInt("idade");

        textNome.setText("nome: "+nome);
       textIdade.setText("idade: "+idade);

    }
}